#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <tuple>
#include <unordered_map>
#include <algorithm>
#include <fstream>
#include <map>

// A struct to save the Trade information
struct Trade {
    long timeStamp;
    std::string symbol;
    int quantity;
    int price;
};

// A struct to save symbolstats
struct SymbolStats {
    int maxTimeGap = 0;
    int totalVolume = 0;
    long long totalWeightedPrice = 0;
    int maxPrice = 0;
    long lastTimeStamp = -1; // Initialized as -1
};

std::vector<Trade> readTradesFromFile(const std::string& filename);
std::unordered_map<std::string, SymbolStats> calculateStatistics(const std::vector<Trade>& trades);
void writeStatisticsToFile(const std::unordered_map<std::string, SymbolStats>& stats, const std::string& filename);

int main() {
    std::string inputFilename = "input.csv";
    std::string outputFilename = "output.csv";

    // read data from "input.csv"
    auto trades = readTradesFromFile(inputFilename);
    if (trades.empty()) {
        std::cerr << "No trades read from file, exiting program." << std::endl;
        return 1; 
    }

    auto stats = calculateStatistics(trades);

    writeStatisticsToFile(stats, outputFilename);

    std::cout << "Statistics have been written to " << outputFilename << std::endl;

    return 0;
}

// Definition of readTrades function
std::vector<Trade> readTradesFromFile(const std::string& filename) {
    std::ifstream file(filename);
    std::vector<Trade> trades;
    if (!file.is_open()) {
        std::cerr << "cannot open file 'input.csv' " << filename << std::endl;
        return trades;
    }

    std::string line;
    while (std::getline(file, line)) {
        std::istringstream iss(line);
        std::string temp;
        std::vector<std::string> tokens;
        while (std::getline(iss, temp, ',')) {
            tokens.push_back(temp);
        }

        if (tokens.size() == 4) {
            Trade trade;
            trade.timeStamp = std::stol(tokens[0]);
            trade.symbol = tokens[1];
            trade.quantity = std::stoi(tokens[2]);
            trade.price = std::stoi(tokens[3]);
            trades.push_back(trade);
        }
    }

    file.close();
    return trades;
}

std::unordered_map<std::string, SymbolStats> calculateStatistics(const std::vector<Trade>& trades) {
    std::unordered_map<std::string, SymbolStats> stats;
    for (const auto& trade : trades) {
        SymbolStats& stat = stats[trade.symbol];
        if (stat.lastTimeStamp != -1) {
            int timeGap = static_cast<int>(trade.timeStamp - stat.lastTimeStamp);
            if (timeGap > stat.maxTimeGap) {
                stat.maxTimeGap = timeGap;
            }
        }
        stat.lastTimeStamp = trade.timeStamp;
        stat.totalVolume += trade.quantity;
        stat.totalWeightedPrice += static_cast<long long>(trade.quantity) * trade.price;
        if (trade.price > stat.maxPrice) {
            stat.maxPrice = trade.price;
        }
    }

    return stats;
}

void writeStatisticsToFile(const std::unordered_map<std::string, SymbolStats>& unsortedStats, const std::string& filename) {

    std::map<std::string, SymbolStats> stats(unsortedStats.begin(), unsortedStats.end());
    
    std::ofstream outFile(filename);
    if (!outFile.is_open()) {
        std::cerr << "cannot open file " << filename << " write data" << std::endl;
        return;
    }

    outFile << "symbol,MaxTimeGap,Volume,WeightedAveragePrice,MaxPrice\n";
    
    for (const auto& pair : stats) {
        const auto& symbol = pair.first;
        const auto& stat = pair.second;
        int weightedAveragePrice = stat.totalVolume > 0 ? static_cast<int>(stat.totalWeightedPrice / stat.totalVolume) : 0;
        outFile << symbol << ","
                << stat.maxTimeGap << ","
                << stat.totalVolume << ","
                << weightedAveragePrice << ","
                << stat.maxPrice << "\n";
    }
    
    outFile.close();
}
